export const font = {
  base: "Arial, sans-serif",
  size: {
    sm: "0.85rem",
    base: "1rem",
    lg: "1.2rem"
  },
  weight: {
    normal: "400",
    bold: "700"
  }
};
